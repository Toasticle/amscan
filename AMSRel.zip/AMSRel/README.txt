Running bootstrap will automatically update all the files.
Running AMScan will start the scanner application.

<3 - Toasticle